document.addEventListener('DOMContentLoaded', () => {
    console.log("Smm Gamerz Website Loaded!");
});
